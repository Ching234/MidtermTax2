package com.example.midtermtax2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

// Warning when using this app or when running them on your end when testing
// The biggest issue is the gradle scripts and the phone that used
// This mean you need change to libs.versions.tomi downgraded the version to make it run.
// Put "8.2.2" instead of 8.3.0 and try latest phone to work if the app not working.

class MainActivity : AppCompatActivity() {

    private lateinit var editTextPrice: EditText
    private lateinit var editTextQuantity: EditText
    private lateinit var textViewSubtotal: TextView
    private lateinit var textViewTotal: TextView
    private lateinit var buttonCalculate: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI elements
        // This section Search the views of EditText, TextView, and Button to set up them.
        editTextPrice = findViewById(R.id.editTextPrice)
        editTextQuantity = findViewById(R.id.editTextQuantity)
        textViewSubtotal = findViewById(R.id.textViewSubtotal)
        textViewTotal = findViewById(R.id.textViewTotal)
        buttonCalculate = findViewById(R.id.buttonCalculate)

        buttonCalculate.setOnClickListener {
            calculateTotal()
        }
    }

    // This section an instruction to update TextViews and compute the total
    // This mean will ask user input of the number will be display of the total
    // Base on the price and quantity the user enter with, and after tex
    private fun calculateTotal() {
        val priceText = editTextPrice.text.toString()
        val quantityText = editTextQuantity.text.toString()

        if (priceText.isBlank() || quantityText.isBlank()) {
            textViewSubtotal.text = "Enter valid numbers!"
            textViewTotal.text = ""
            return
        }

        val price = priceText.toDoubleOrNull()
        val quantity = quantityText.toDoubleOrNull()

        if (price == null || quantity == null) {
            textViewSubtotal.text = "Invalid input!"
            textViewTotal.text = ""
            return
        }

        val subtotal = price * quantity
        val tax = subtotal * 0.06
        val total = subtotal + tax

        textViewSubtotal.text = String.format("Subtotal: $%.2f", subtotal)
        textViewTotal.text = String.format("Total with Tax: $%.2f", total)
    }
}
